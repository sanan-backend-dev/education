"""Обработка заказов в демо-ресторане (in-memory)."""

import logging
import uuid

import httpx

from app.config import settings

logger = logging.getLogger(__name__)

# In-memory хранилище заказов
orders: dict[str, dict] = {}


async def receive_order(order_data: dict) -> dict:
    """Принять заказ от Kitchen API."""
    external_order_id = f"rest-order-{uuid.uuid4().hex[:8]}"

    orders[external_order_id] = {
        "external_order_id": external_order_id,
        "kitchen_order_id": order_data["kitchen_order_id"],
        "items": order_data["items"],
        "customer_name": order_data.get("customer_name", ""),
        "status": "RECEIVED",
    }

    logger.info("Принят заказ %s (kitchen: %s)", external_order_id, order_data["kitchen_order_id"])
    return {"external_order_id": external_order_id, "status": "RECEIVED"}


async def update_status(external_order_id: str, new_status: str) -> dict:
    """Обновить статус заказа и отправить webhook в Kitchen API."""
    if external_order_id not in orders:
        raise ValueError(f"Заказ {external_order_id} не найден")

    order = orders[external_order_id]
    order["status"] = new_status

    # Отправляем webhook в Kitchen API
    kitchen_order_id = order["kitchen_order_id"]
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{settings.kitchen_api_url}/api/v1/webhooks/orders/{kitchen_order_id}/status",
                json={
                    "status": new_status,
                    "external_order_id": external_order_id,
                },
            )
            response.raise_for_status()
            logger.info(
                "Webhook отправлен: заказ %s → %s", external_order_id, new_status
            )
    except Exception as e:
        logger.warning("Не удалось отправить webhook: %s", e)

    return order
