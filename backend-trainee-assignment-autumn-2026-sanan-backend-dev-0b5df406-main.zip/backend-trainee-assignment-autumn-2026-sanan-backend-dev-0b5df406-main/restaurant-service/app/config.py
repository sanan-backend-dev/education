from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Настройки Restaurant Service."""

    kitchen_api_url: str = "http://kitchen-api:8000"

    model_config = {"env_prefix": ""}


settings = Settings()
