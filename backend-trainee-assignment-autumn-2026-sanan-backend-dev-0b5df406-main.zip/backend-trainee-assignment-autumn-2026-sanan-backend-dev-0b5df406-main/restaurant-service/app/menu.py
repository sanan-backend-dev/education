"""Хардкожённое меню демо-ресторана (source of truth)."""

MENU: list[dict] = [
    {
        "id": "burger-01",
        "name": "Классический бургер",
        "description": "Говяжья котлета, салат, томат, соус",
        "price": 45000,
        "is_available": True,
    },
    {
        "id": "fries-01",
        "name": "Картофель фри",
        "description": "Хрустящий картофель с солью",
        "price": 15000,
        "is_available": True,
    },
    {
        "id": "cola-01",
        "name": "Кола 0.5л",
        "description": "Прохладительный напиток",
        "price": 10000,
        "is_available": True,
    },
    {
        "id": "salad-01",
        "name": "Цезарь с курицей",
        "description": "Салат Цезарь с куриным филе и пармезаном",
        "price": 35000,
        "is_available": False,  # Недоступен — для теста edge case
    },
]
