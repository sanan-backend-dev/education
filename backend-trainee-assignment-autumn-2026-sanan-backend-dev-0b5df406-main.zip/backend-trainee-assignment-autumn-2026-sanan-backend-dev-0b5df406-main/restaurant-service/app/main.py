import logging

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from app.menu import MENU
from app.orders import orders, receive_order, update_status

logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="Restaurant Service",
    description="Демо-ресторан для Авито.Кухня",
    version="0.1.0",
)


@app.get("/healthz", tags=["health"])
async def healthz() -> dict:
    """Проверка работоспособности."""
    return {"status": "ok", "service": "restaurant-service"}


@app.get("/api/menu", tags=["menu"])
async def get_menu() -> dict:
    """Получить меню ресторана (source of truth)."""
    return {"items": MENU}


@app.post("/api/orders", tags=["orders"])
async def create_order(order_data: dict) -> dict:
    """Принять заказ от Kitchen API."""
    result = await receive_order(order_data)
    return result


class UpdateStatusRequest(BaseModel):
    status: str


@app.post("/api/orders/{external_order_id}/status", tags=["orders"])
async def change_order_status(
    external_order_id: str, request: UpdateStatusRequest
) -> dict:
    """Обновить статус заказа (для демо/тестирования).

    После обновления статуса отправляет webhook в Kitchen API.
    """
    try:
        result = await update_status(external_order_id, request.status)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/orders", tags=["orders"])
async def list_orders() -> dict:
    """Список всех заказов (для демо/тестирования)."""
    return {"orders": list(orders.values())}
