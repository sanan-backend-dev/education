import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import async_session
from app.models.restaurant import Restaurant

logger = logging.getLogger(__name__)

# Данные демо-ресторана для seed
DEMO_RESTAURANT = {
    "name": "Бургерная №1",
    "description": "Лучшие бургеры в городе",
    "address": "ул. Пушкина, 10",
    "is_active": True,
    "external_id": "restaurant-01",
    "webhook_url": "http://restaurant-service:8001",
}


async def run_seed() -> None:
    """Создаёт начальные данные, если их нет (idempotent)."""
    async with async_session() as session:
        await _seed_restaurant(session)


async def _seed_restaurant(session: AsyncSession) -> None:
    """Создаёт демо-ресторан, если его ещё нет."""
    result = await session.execute(
        select(Restaurant).where(
            Restaurant.external_id == DEMO_RESTAURANT["external_id"]
        )
    )
    if result.scalar_one_or_none() is not None:
        logger.info("Демо-ресторан уже существует, пропускаем seed")
        return

    restaurant = Restaurant(**DEMO_RESTAURANT)
    session.add(restaurant)
    await session.commit()
    logger.info("Демо-ресторан '%s' создан", DEMO_RESTAURANT["name"])
