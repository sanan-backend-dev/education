import uuid
from datetime import datetime

from pydantic import BaseModel, Field

from app.models.order import OrderStatus


class OrderItemRequest(BaseModel):
    """Позиция в запросе на создание заказа."""

    menu_item_id: uuid.UUID
    quantity: int = Field(gt=0, description="Количество (> 0)")


class CreateOrderRequest(BaseModel):
    """Запрос на создание заказа."""

    restaurant_id: uuid.UUID
    customer_name: str = Field(min_length=1, max_length=255)
    customer_phone: str = Field(min_length=1, max_length=50)
    delivery_address: str | None = None
    items: list[OrderItemRequest] = Field(min_length=1)


class OrderItemResponse(BaseModel):
    """Позиция заказа в ответе API."""

    id: uuid.UUID
    menu_item_id: uuid.UUID
    quantity: int
    price_at_order: int
    name_at_order: str

    model_config = {"from_attributes": True}


class OrderResponse(BaseModel):
    """Заказ в ответе API."""

    id: uuid.UUID
    restaurant_id: uuid.UUID
    status: OrderStatus
    total_price: int
    customer_name: str
    customer_phone: str
    delivery_address: str | None
    items: list[OrderItemResponse]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class UpdateOrderStatusRequest(BaseModel):
    """Запрос от ресторана на обновление статуса заказа."""

    status: OrderStatus
    external_order_id: str | None = None
