import uuid
from datetime import datetime

from pydantic import BaseModel


class RestaurantResponse(BaseModel):
    """Ресторан в ответе API."""

    id: uuid.UUID
    name: str
    description: str | None
    address: str | None
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class RestaurantListResponse(BaseModel):
    """Список ресторанов."""

    restaurants: list[RestaurantResponse]
