import uuid

from pydantic import BaseModel


class MenuItemResponse(BaseModel):
    """Позиция меню в ответе API."""

    id: uuid.UUID
    name: str
    description: str | None
    price: int  # копейки
    is_available: bool

    model_config = {"from_attributes": True}


class MenuResponse(BaseModel):
    """Меню ресторана."""

    restaurant_id: uuid.UUID
    items: list[MenuItemResponse]
    cached: bool = False
