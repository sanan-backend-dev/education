import uuid

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.order import CreateOrderRequest, OrderResponse
from app.services import order_service

router = APIRouter(prefix="/api/v1/orders", tags=["orders"])


@router.post("", response_model=OrderResponse, status_code=status.HTTP_201_CREATED)
async def create_order(
    request: CreateOrderRequest, db: AsyncSession = Depends(get_db)
) -> OrderResponse:
    """Создать заказ."""
    order = await order_service.create_order(
        session=db,
        restaurant_id=request.restaurant_id,
        customer_name=request.customer_name,
        customer_phone=request.customer_phone,
        delivery_address=request.delivery_address,
        items=[
            {"menu_item_id": item.menu_item_id, "quantity": item.quantity}
            for item in request.items
        ],
    )
    return OrderResponse.model_validate(order)


@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: uuid.UUID, db: AsyncSession = Depends(get_db)
) -> OrderResponse:
    """Получить информацию о заказе."""
    order = await order_service.get_order(db, order_id)
    return OrderResponse.model_validate(order)


@router.post("/{order_id}/cancel", response_model=OrderResponse)
async def cancel_order(
    order_id: uuid.UUID, db: AsyncSession = Depends(get_db)
) -> OrderResponse:
    """Отменить заказ (только в статусе PENDING)."""
    order = await order_service.cancel_order(db, order_id)
    return OrderResponse.model_validate(order)
