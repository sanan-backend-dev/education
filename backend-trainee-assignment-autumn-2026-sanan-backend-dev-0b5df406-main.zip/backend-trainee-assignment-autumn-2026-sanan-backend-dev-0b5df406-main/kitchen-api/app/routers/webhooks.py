import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.order import OrderResponse, UpdateOrderStatusRequest
from app.services import order_service

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


@router.post("/orders/{order_id}/status", response_model=OrderResponse)
async def update_order_status(
    order_id: uuid.UUID,
    request: UpdateOrderStatusRequest,
    db: AsyncSession = Depends(get_db),
) -> OrderResponse:
    """Webhook: ресторан обновляет статус заказа."""
    order = await order_service.update_order_status(
        session=db,
        order_id=order_id,
        new_status=request.status,
        external_order_id=request.external_order_id,
    )
    return OrderResponse.model_validate(order)
