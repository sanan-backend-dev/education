import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.menu import MenuItemResponse, MenuResponse
from app.schemas.restaurant import RestaurantListResponse, RestaurantResponse
from app.services import menu_service, restaurant_service

router = APIRouter(prefix="/api/v1/restaurants", tags=["restaurants"])


@router.get("", response_model=RestaurantListResponse)
async def list_restaurants(
    db: AsyncSession = Depends(get_db),
) -> RestaurantListResponse:
    """Получить список всех активных заведений."""
    restaurants = await restaurant_service.get_all_restaurants(db)
    return RestaurantListResponse(
        restaurants=[RestaurantResponse.model_validate(r) for r in restaurants]
    )


@router.get("/{restaurant_id}/menu", response_model=MenuResponse)
async def get_menu(
    restaurant_id: uuid.UUID, db: AsyncSession = Depends(get_db)
) -> MenuResponse:
    """Получить меню заведения (Lazy Pull).

    Пытается получить актуальное меню от ресторана.
    При недоступности — возвращает кэш с cached=true.
    """
    items, cached = await menu_service.get_menu(db, restaurant_id)
    return MenuResponse(
        restaurant_id=restaurant_id,
        items=[MenuItemResponse.model_validate(i) for i in items],
        cached=cached,
    )
