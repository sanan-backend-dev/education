from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Настройки приложения. Значения читаются из переменных окружения."""

    database_url: str = "postgresql+asyncpg://kitchen_user:kitchen_pass@postgres:5432/kitchen"
    restaurant_service_url: str = "http://restaurant-service:8001"

    model_config = {"env_prefix": ""}


settings = Settings()
