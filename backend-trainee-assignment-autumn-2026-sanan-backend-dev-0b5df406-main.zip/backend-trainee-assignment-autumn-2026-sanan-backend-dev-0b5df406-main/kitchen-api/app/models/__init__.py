from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Базовый класс для всех моделей SQLAlchemy."""

    pass


# Импортируем все модели, чтобы Alembic видел их через Base.metadata.
# Порядок важен: сначала модели без FK, потом зависимые.
from app.models.restaurant import Restaurant as Restaurant  # noqa: E402, F401
from app.models.menu_item import MenuItem as MenuItem  # noqa: E402, F401
from app.models.order import Order as Order  # noqa: E402, F401
from app.models.order import OrderStatus as OrderStatus  # noqa: E402, F401
from app.models.order import VALID_TRANSITIONS as VALID_TRANSITIONS  # noqa: E402, F401
from app.models.order_item import OrderItem as OrderItem  # noqa: E402, F401
