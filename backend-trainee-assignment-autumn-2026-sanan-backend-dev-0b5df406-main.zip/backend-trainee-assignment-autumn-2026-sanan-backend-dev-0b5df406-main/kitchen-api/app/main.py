import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.exceptions import ConflictError, NotFoundError, ServiceUnavailableError, ValidationError
from app.routers import orders, restaurants, webhooks
from app.seed import run_seed

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown events."""
    if os.getenv("TESTING") != "1":
        logger.info("Запускаем seed данных...")
        await run_seed()
        logger.info("Seed завершён")
    yield


app = FastAPI(
    title="Авито.Кухня API",
    description="MVP сервиса заказа еды",
    version="0.1.0",
    lifespan=lifespan,
)

# Подключаем роутеры
app.include_router(restaurants.router)
app.include_router(orders.router)
app.include_router(webhooks.router)


# --- Обработчики ошибок ---


@app.exception_handler(NotFoundError)
async def not_found_handler(request: Request, exc: NotFoundError) -> JSONResponse:
    return JSONResponse(status_code=404, content={"detail": exc.detail})


@app.exception_handler(ValidationError)
async def validation_handler(request: Request, exc: ValidationError) -> JSONResponse:
    return JSONResponse(status_code=422, content={"detail": exc.detail})


@app.exception_handler(ConflictError)
async def conflict_handler(request: Request, exc: ConflictError) -> JSONResponse:
    return JSONResponse(status_code=409, content={"detail": exc.detail})


@app.exception_handler(ServiceUnavailableError)
async def unavailable_handler(
    request: Request, exc: ServiceUnavailableError
) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": exc.detail})


@app.get("/healthz", tags=["health"])
async def healthz() -> dict:
    """Проверка работоспособности сервиса."""
    return {"status": "ok", "service": "kitchen-api"}
