import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.exceptions import NotFoundError
from app.models.restaurant import Restaurant


async def get_all_restaurants(session: AsyncSession) -> list[Restaurant]:
    """Получить все активные рестораны."""
    result = await session.execute(
        select(Restaurant)
        .where(Restaurant.is_active.is_(True))
        .order_by(Restaurant.name)
    )
    return list(result.scalars().all())


async def get_restaurant_by_id(
    session: AsyncSession, restaurant_id: uuid.UUID
) -> Restaurant:
    """Получить ресторан по ID."""
    result = await session.execute(
        select(Restaurant).where(Restaurant.id == restaurant_id)
    )
    restaurant = result.scalar_one_or_none()
    if restaurant is None:
        raise NotFoundError(f"Ресторан {restaurant_id} не найден")
    return restaurant
