import logging
import uuid

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.exceptions import NotFoundError, ServiceUnavailableError
from app.models.menu_item import MenuItem
from app.models.restaurant import Restaurant

logger = logging.getLogger(__name__)


async def get_menu(
    session: AsyncSession, restaurant_id: uuid.UUID
) -> tuple[list[MenuItem], bool]:
    """Получить меню ресторана (Lazy Pull).

    Returns:
        (список позиций меню, cached: True если из кэша)
    """
    # 1. Проверяем ресторан
    result = await session.execute(
        select(Restaurant).where(Restaurant.id == restaurant_id)
    )
    restaurant = result.scalar_one_or_none()
    if restaurant is None:
        raise NotFoundError(f"Ресторан {restaurant_id} не найден")

    webhook_url = restaurant.webhook_url
    rest_id = restaurant.id

    # 2. Пытаемся получить актуальное меню из ресторана
    remote_items: list[dict] | None = None
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{webhook_url}/api/menu")
            response.raise_for_status()
            remote_items = response.json()["items"]
    except Exception as e:
        logger.warning("Не удалось получить меню от ресторана %s: %s", restaurant_id, e)

    # 3. Если получили — обновляем кэш
    if remote_items is not None:
        try:
            await _sync_menu(session, rest_id, remote_items)
            await session.commit()
        except Exception as e:
            logger.error("Ошибка синхронизации меню: %s", e)
            await session.rollback()

    # 4. Возвращаем данные из кэша
    items = await _get_cached_menu(session, rest_id)

    if items:
        # cached=True если данные получены из локального кэша БД
        return items, remote_items is None
    elif remote_items is None:
        raise ServiceUnavailableError(
            f"Ресторан {restaurant_id} недоступен и кэш меню отсутствует"
        )
    else:
        return items, False  # Пустое меню от ресторана


async def _sync_menu(
    session: AsyncSession, restaurant_id: uuid.UUID, remote_items: list[dict]
) -> None:
    """Upsert: обновляет кэш меню данными от ресторана."""
    remote_external_ids: list[str] = []

    for item_data in remote_items:
        external_id = item_data["id"]
        remote_external_ids.append(external_id)

        result = await session.execute(
            select(MenuItem).where(
                MenuItem.restaurant_id == restaurant_id,
                MenuItem.external_id == external_id,
            )
        )
        existing = result.scalar_one_or_none()

        if existing:
            existing.name = item_data["name"]
            existing.description = item_data.get("description")
            existing.price = item_data["price"]
            existing.is_available = item_data["is_available"]
        else:
            session.add(
                MenuItem(
                    restaurant_id=restaurant_id,
                    external_id=external_id,
                    name=item_data["name"],
                    description=item_data.get("description"),
                    price=item_data["price"],
                    is_available=item_data["is_available"],
                )
            )

    await session.flush()

    if remote_external_ids:
        result = await session.execute(
            select(MenuItem).where(
                MenuItem.restaurant_id == restaurant_id,
                MenuItem.external_id.notin_(remote_external_ids),
            )
        )
        for old_item in result.scalars().all():
            old_item.is_available = False


async def _get_cached_menu(
    session: AsyncSession, restaurant_id: uuid.UUID
) -> list[MenuItem]:
    """Получить кэшированное меню из БД."""
    result = await session.execute(
        select(MenuItem)
        .where(MenuItem.restaurant_id == restaurant_id)
        .order_by(MenuItem.name)
    )
    return list(result.scalars().all())
