import logging
import uuid

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.exceptions import ConflictError, NotFoundError, ValidationError
from app.models.menu_item import MenuItem
from app.models.order import VALID_TRANSITIONS, Order, OrderStatus
from app.models.order_item import OrderItem
from app.models.restaurant import Restaurant

logger = logging.getLogger(__name__)


async def create_order(
    session: AsyncSession,
    restaurant_id: uuid.UUID,
    customer_name: str,
    customer_phone: str,
    delivery_address: str | None,
    items: list[dict],
) -> Order:
    """Создать заказ.

    Одна транзакция: проверка → Order → OrderItems → total_price → commit.
    После commit — отправка в ресторан (best effort).
    """
    # 1. Проверяем ресторан
    result = await session.execute(
        select(Restaurant).where(Restaurant.id == restaurant_id)
    )
    restaurant = result.scalar_one_or_none()
    if restaurant is None:
        raise NotFoundError(f"Ресторан {restaurant_id} не найден")
    if not restaurant.is_active:
        raise ValidationError(f"Ресторан {restaurant_id} временно не работает")

    # 2. Загружаем menu_items из кэша (БД)
    menu_item_ids = [item["menu_item_id"] for item in items]
    result = await session.execute(
        select(MenuItem).where(
            MenuItem.id.in_(menu_item_ids),
            MenuItem.restaurant_id == restaurant_id,
        )
    )
    menu_items_map: dict[uuid.UUID, MenuItem] = {
        mi.id: mi for mi in result.scalars().all()
    }

    # 3. Валидация каждого товара
    not_found = []
    unavailable = []
    for item in items:
        mi = menu_items_map.get(item["menu_item_id"])
        if mi is None:
            not_found.append(str(item["menu_item_id"]))
        elif not mi.is_available:
            unavailable.append(mi.name)

    if not_found:
        raise NotFoundError(f"Товары не найдены: {', '.join(not_found)}")
    if unavailable:
        raise ValidationError(f"Товары недоступны: {', '.join(unavailable)}")

    # 4. Создаём Order + OrderItems в одной транзакции
    order = Order(
        restaurant_id=restaurant_id,
        customer_name=customer_name,
        customer_phone=customer_phone,
        delivery_address=delivery_address,
        status=OrderStatus.PENDING.value,
        total_price=0,
    )
    session.add(order)
    await session.flush()  # получаем order.id

    total_price = 0
    for item in items:
        mi = menu_items_map[item["menu_item_id"]]
        order_item = OrderItem(
            order_id=order.id,
            menu_item_id=mi.id,
            quantity=item["quantity"],
            price_at_order=mi.price,
            name_at_order=mi.name,
        )
        session.add(order_item)
        total_price += mi.price * item["quantity"]

    order.total_price = total_price
    await session.commit()

    # 5. Отправляем в ресторан (best effort — если упадёт, заказ всё равно создан)
    await _send_order_to_restaurant(session, restaurant, order, items, menu_items_map)

    # Перезагружаем с items для ответа
    result = await session.execute(
        select(Order).options(selectinload(Order.items)).where(Order.id == order.id)
    )
    return result.scalar_one()


async def get_order(session: AsyncSession, order_id: uuid.UUID) -> Order:
    """Получить заказ по ID с позициями."""
    result = await session.execute(
        select(Order).options(selectinload(Order.items)).where(Order.id == order_id)
    )
    order = result.scalar_one_or_none()
    if order is None:
        raise NotFoundError(f"Заказ {order_id} не найден")
    return order


async def cancel_order(session: AsyncSession, order_id: uuid.UUID) -> Order:
    """Отменить заказ (только из PENDING)."""
    order = await get_order(session, order_id)

    if order.status != OrderStatus.PENDING.value:
        raise ConflictError(
            f"Нельзя отменить заказ в статусе {order.status}. "
            f"Отмена возможна только в статусе PENDING"
        )

    order.status = OrderStatus.CANCELLED.value
    await session.commit()
    await session.refresh(order)
    return order


async def update_order_status(
    session: AsyncSession,
    order_id: uuid.UUID,
    new_status: OrderStatus,
    external_order_id: str | None = None,
) -> Order:
    """Обновить статус заказа (webhook от ресторана)."""
    order = await get_order(session, order_id)

    current = OrderStatus(order.status)
    allowed = VALID_TRANSITIONS.get(current, set())
    if new_status not in allowed:
        allowed_str = ", ".join(s.value for s in allowed) if allowed else "нет"
        raise ConflictError(
            f"Недопустимый переход: {current.value} → {new_status.value}. "
            f"Допустимые: {allowed_str}"
        )

    order.status = new_status.value
    if external_order_id:
        order.external_order_id = external_order_id

    await session.commit()
    await session.refresh(order)
    return order


async def _send_order_to_restaurant(
    session: AsyncSession,
    restaurant: Restaurant,
    order: Order,
    items: list[dict],
    menu_items_map: dict[uuid.UUID, MenuItem],
) -> None:
    """Отправить заказ в Restaurant Service."""
    order_payload = {
        "kitchen_order_id": str(order.id),
        "items": [
            {
                "external_id": menu_items_map[item["menu_item_id"]].external_id,
                "quantity": item["quantity"],
                "price": menu_items_map[item["menu_item_id"]].price,
                "name": menu_items_map[item["menu_item_id"]].name,
            }
            for item in items
        ],
        "customer_name": order.customer_name,
        "delivery_address": order.delivery_address,
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{restaurant.webhook_url}/api/orders", json=order_payload
            )
            response.raise_for_status()
            data = response.json()
            if "external_order_id" in data:
                order.external_order_id = data["external_order_id"]
                await session.commit()
    except Exception as e:
        logger.warning("Не удалось отправить заказ %s в ресторан: %s", order.id, e)
