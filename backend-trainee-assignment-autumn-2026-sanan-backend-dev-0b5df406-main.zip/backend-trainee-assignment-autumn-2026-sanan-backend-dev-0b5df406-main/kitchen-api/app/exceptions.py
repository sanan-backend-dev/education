class NotFoundError(Exception):
    """Ресурс не найден (404)."""

    def __init__(self, detail: str = "Ресурс не найден"):
        self.detail = detail


class ValidationError(Exception):
    """Ошибка валидации бизнес-правил (422)."""

    def __init__(self, detail: str = "Ошибка валидации"):
        self.detail = detail


class ConflictError(Exception):
    """Конфликт состояния (409)."""

    def __init__(self, detail: str = "Конфликт состояния"):
        self.detail = detail


class ServiceUnavailableError(Exception):
    """Внешний сервис недоступен (503)."""

    def __init__(self, detail: str = "Сервис временно недоступен"):
        self.detail = detail
