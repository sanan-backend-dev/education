from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import settings

# Engine — «движок» подключения к БД.
# Создаётся один раз при старте приложения.
engine = create_async_engine(settings.database_url, echo=False)

# SessionLocal — фабрика сессий.
# Каждый запрос к API получает свою сессию (= своё соединение с БД).
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency для FastAPI: создаёт сессию на время запроса.

    Используется так:
        @app.get("/something")
        async def handler(db: AsyncSession = Depends(get_db)):
            ...

    yield отдаёт сессию в обработчик.
    После завершения запроса — сессия закрывается автоматически.
    """
    async with async_session() as session:
        yield session
