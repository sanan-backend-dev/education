"""Тесты API Kitchen."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest


# --- Тесты ресторанов ---


@pytest.mark.asyncio
async def test_list_restaurants(client, restaurant):
    """Успешное получение списка ресторанов."""
    response = await client.get("/api/v1/restaurants")
    assert response.status_code == 200
    data = response.json()
    assert len(data["restaurants"]) == 1
    assert data["restaurants"][0]["name"] == "Тестовый ресторан"


@pytest.mark.asyncio
async def test_list_restaurants_empty(client):
    """Пустой список ресторанов."""
    response = await client.get("/api/v1/restaurants")
    assert response.status_code == 200
    assert len(response.json()["restaurants"]) == 0


# --- Тесты меню ---


@pytest.mark.asyncio
async def test_get_menu_cached(client, restaurant, menu_items):
    """Получение меню из кэша при недоступности ресторана."""
    with patch("app.services.menu_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.ConnectError("Connection refused")
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        response = await client.get(f"/api/v1/restaurants/{restaurant.id}/menu")
        assert response.status_code == 200
        data = response.json()
        assert data["cached"] is True
        assert len(data["items"]) == 3


@pytest.mark.asyncio
async def test_get_menu_not_found(client):
    """Меню несуществующего ресторана."""
    response = await client.get(
        "/api/v1/restaurants/00000000-0000-0000-0000-000000000000/menu"
    )
    assert response.status_code == 404


# --- Тесты заказов ---


@pytest.mark.asyncio
async def test_create_order(client, restaurant, menu_items):
    """Успешное создание заказа."""
    available_items = [i for i in menu_items if i.is_available]

    with patch("app.services.order_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "external_order_id": "rest-order-1",
            "status": "RECEIVED",
        }
        mock_response.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        response = await client.post(
            "/api/v1/orders",
            json={
                "restaurant_id": str(restaurant.id),
                "customer_name": "Иван",
                "customer_phone": "+79991234567",
                "items": [
                    {"menu_item_id": str(available_items[0].id), "quantity": 2},
                    {"menu_item_id": str(available_items[1].id), "quantity": 1},
                ],
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["status"] == "PENDING"
        # 2 * 50000 + 1 * 15000 = 115000
        assert data["total_price"] == 115000
        assert len(data["items"]) == 2


@pytest.mark.asyncio
async def test_create_order_unavailable_item(client, restaurant, menu_items):
    """Нельзя заказать недоступный товар."""
    unavailable = [i for i in menu_items if not i.is_available][0]
    response = await client.post(
        "/api/v1/orders",
        json={
            "restaurant_id": str(restaurant.id),
            "customer_name": "Иван",
            "customer_phone": "+79991234567",
            "items": [{"menu_item_id": str(unavailable.id), "quantity": 1}],
        },
    )
    assert response.status_code == 422
    assert "недоступны" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_create_order_empty_items(client, restaurant):
    """Нельзя создать заказ без товаров."""
    response = await client.post(
        "/api/v1/orders",
        json={
            "restaurant_id": str(restaurant.id),
            "customer_name": "Иван",
            "customer_phone": "+79991234567",
            "items": [],
        },
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_create_order_zero_quantity(client, restaurant, menu_items):
    """Нельзя заказать quantity <= 0."""
    available = [i for i in menu_items if i.is_available][0]
    response = await client.post(
        "/api/v1/orders",
        json={
            "restaurant_id": str(restaurant.id),
            "customer_name": "Иван",
            "customer_phone": "+79991234567",
            "items": [{"menu_item_id": str(available.id), "quantity": 0}],
        },
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_get_order(client, restaurant, menu_items):
    """Получение информации о заказе."""
    available = [i for i in menu_items if i.is_available][0]

    with patch("app.services.order_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"external_order_id": "rest-order-1"}
        mock_response.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        create_resp = await client.post(
            "/api/v1/orders",
            json={
                "restaurant_id": str(restaurant.id),
                "customer_name": "Иван",
                "customer_phone": "+79991234567",
                "items": [{"menu_item_id": str(available.id), "quantity": 1}],
            },
        )
        order_id = create_resp.json()["id"]

    response = await client.get(f"/api/v1/orders/{order_id}")
    assert response.status_code == 200
    assert response.json()["id"] == order_id


@pytest.mark.asyncio
async def test_get_order_not_found(client):
    """Несуществующий заказ."""
    response = await client.get(
        "/api/v1/orders/00000000-0000-0000-0000-000000000000"
    )
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_cancel_order(client, restaurant, menu_items):
    """Отмена заказа в статусе PENDING."""
    available = [i for i in menu_items if i.is_available][0]

    with patch("app.services.order_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"external_order_id": "rest-order-1"}
        mock_response.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        create_resp = await client.post(
            "/api/v1/orders",
            json={
                "restaurant_id": str(restaurant.id),
                "customer_name": "Иван",
                "customer_phone": "+79991234567",
                "items": [{"menu_item_id": str(available.id), "quantity": 1}],
            },
        )
        order_id = create_resp.json()["id"]

    cancel_resp = await client.post(f"/api/v1/orders/{order_id}/cancel")
    assert cancel_resp.status_code == 200
    assert cancel_resp.json()["status"] == "CANCELLED"


@pytest.mark.asyncio
async def test_webhook_update_status(client, restaurant, menu_items):
    """Ресторан обновляет статус заказа через webhook."""
    available = [i for i in menu_items if i.is_available][0]

    with patch("app.services.order_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"external_order_id": "rest-order-1"}
        mock_response.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        create_resp = await client.post(
            "/api/v1/orders",
            json={
                "restaurant_id": str(restaurant.id),
                "customer_name": "Иван",
                "customer_phone": "+79991234567",
                "items": [{"menu_item_id": str(available.id), "quantity": 1}],
            },
        )
        order_id = create_resp.json()["id"]

    # Ресторан подтверждает заказ
    resp = await client.post(
        f"/api/v1/webhooks/orders/{order_id}/status",
        json={"status": "CONFIRMED"},
    )
    assert resp.status_code == 200
    assert resp.json()["status"] == "CONFIRMED"


@pytest.mark.asyncio
async def test_webhook_invalid_transition(client, restaurant, menu_items):
    """Недопустимый переход статуса."""
    available = [i for i in menu_items if i.is_available][0]

    with patch("app.services.order_service.httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"external_order_id": "rest-order-1"}
        mock_response.raise_for_status = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)

        create_resp = await client.post(
            "/api/v1/orders",
            json={
                "restaurant_id": str(restaurant.id),
                "customer_name": "Иван",
                "customer_phone": "+79991234567",
                "items": [{"menu_item_id": str(available.id), "quantity": 1}],
            },
        )
        order_id = create_resp.json()["id"]

    # Нельзя перейти из PENDING сразу в PREPARING
    resp = await client.post(
        f"/api/v1/webhooks/orders/{order_id}/status",
        json={"status": "PREPARING"},
    )
    assert resp.status_code == 409
