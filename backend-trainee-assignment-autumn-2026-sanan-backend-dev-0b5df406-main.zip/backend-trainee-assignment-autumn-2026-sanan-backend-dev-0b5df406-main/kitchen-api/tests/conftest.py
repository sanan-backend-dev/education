import os
import uuid
from collections.abc import AsyncGenerator

import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

os.environ["TESTING"] = "1"

from app.config import settings
from app.database import get_db
from app.main import app
from app.models import Base
from app.models.menu_item import MenuItem
from app.models.restaurant import Restaurant

DATABASE_URL = os.getenv("TEST_DATABASE_URL", settings.database_url)

test_engine = create_async_engine(DATABASE_URL, poolclass=NullPool)
TestSessionLocal = async_sessionmaker(
    test_engine, class_=AsyncSession, expire_on_commit=False
)


@pytest_asyncio.fixture(scope="session", autouse=True)
async def setup_db():
    """Создать таблицы перед тестами при необходимости."""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await test_engine.dispose()


@pytest_asyncio.fixture(autouse=True)
async def clean_tables():
    """Очистить все таблицы перед каждым тестом."""
    async with test_engine.begin() as conn:
        for table in reversed(Base.metadata.sorted_tables):
            await conn.execute(table.delete())
    yield


@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    async with TestSessionLocal() as session:
        yield session


@pytest_asyncio.fixture
async def client() -> AsyncGenerator[AsyncClient, None]:
    async def override_get_db() -> AsyncGenerator[AsyncSession, None]:
        async with TestSessionLocal() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def restaurant(db_session: AsyncSession) -> Restaurant:
    """Создать тестовый ресторан."""
    r = Restaurant(
        name="Тестовый ресторан",
        description="Для тестов",
        address="ул. Тестовая, 1",
        is_active=True,
        webhook_url="http://restaurant-service:8001",
        external_id=f"test-{uuid.uuid4().hex[:8]}",
    )
    db_session.add(r)
    await db_session.commit()
    await db_session.refresh(r)
    return r


@pytest_asyncio.fixture
async def menu_items(
    db_session: AsyncSession, restaurant: Restaurant
) -> list[MenuItem]:
    """Создать тестовое меню."""
    items = [
        MenuItem(
            restaurant_id=restaurant.id,
            external_id="burger-01",
            name="Бургер",
            price=50000,
            is_available=True,
        ),
        MenuItem(
            restaurant_id=restaurant.id,
            external_id="fries-01",
            name="Картофель фри",
            price=15000,
            is_available=True,
        ),
        MenuItem(
            restaurant_id=restaurant.id,
            external_id="salad-01",
            name="Салат",
            price=35000,
            is_available=False,
        ),
    ]
    for item in items:
        db_session.add(item)
    await db_session.commit()
    for item in items:
        await db_session.refresh(item)
    return items
